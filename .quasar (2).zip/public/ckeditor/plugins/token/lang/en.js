CKEDITOR.plugins.setLang('token', 'en', {
  title: 'Tokens',
  toolbar: 'Token',
  name: 'Token to Insert',
  pathName: 'token'
});
