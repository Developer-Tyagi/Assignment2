export const photoIdKey = state => state.photoIdKey;
export const userName = state => state.user.name;
export const checkConnection = state => state.checkConnection;
