export default function () {
  return {
    actionOverDues: [],
    actionCompletion: [],
    actionReason: [],
    workflowAction: [],
    allAction: [],
    officeTaskActions: [],
    assignedToData: []
  };
}
