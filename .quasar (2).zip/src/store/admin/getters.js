export const actionOverDues = state => state.actionOverDues;
export const actionCompletion = state => state.actionCompletion;
export const actionReason = state => state.actionReason;
export const workflowAction = state => state.workflowAction;
export const allAction = state => state.allAction;
export const officeTaskActions = state => state.officeTaskActions;
export const assignedToData = state => state.assignedToData;
