export const activeLeads = state => state.activeLeads;
export const archivedLeads = state => state.archivedLeads;
export const selectedLead = state => state.selectedLead;
export const leadStatic = state => state.leadStatic;
export const converted = state => state.converted;
export const isShowConvertButton = state => state.isShowConvertButton;
