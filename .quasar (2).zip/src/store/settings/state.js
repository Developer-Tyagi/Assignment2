export default function () {
  return {
    inspectionTypes: [],
    allUsers: [],
    paidUnpaidUserList: [],
    setAllConfigurationData: []
  };
}
