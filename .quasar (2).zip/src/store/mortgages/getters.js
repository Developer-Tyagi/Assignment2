export const mortgages = state => state.mortgages;
export const selectedMortgage = state => state.selectedMortgage;
export const mortgagePersonnel = state => state.mortgagePersonnel;
