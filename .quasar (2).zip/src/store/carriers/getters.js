export const carriers = state => state.carriers;
export const selectedCarrier = state => state.selectedCarrier;
export const carrierPersonnel = state => state.carrierPersonnel;
export const selectedClaimCarrier = state => state.selectedClaimCarrier;
export const claimRoles = state => state.claimRoles;
