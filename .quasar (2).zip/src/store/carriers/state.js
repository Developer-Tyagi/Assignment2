export default function() {
  return {
    carriers: [],
    selectedCarrier: [],
    carrierPersonnel: [],
    selectedClaimCarrier: [],
    claimRoles: []
  };
}
