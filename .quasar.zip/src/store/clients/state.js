export default function() {
  return {
    clients: [],
    notes: [],
    estimators: [],
    propertyTypes: [],
    policyTypes: [],
    claimReasons: [],
    selectedClient: '',
    claimSeverity: [],
    policyCategories: [],
    editSelectedClient: [],
    selectedClientId: '',
    setClientProperty: [],
    getSelectedClaim: [],
    selectedClaimId: '',
    clientStatic: {}
  };
}
