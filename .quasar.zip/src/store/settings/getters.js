export const inspectionTypes = state => state.inspectionTypes.map(type => type);
export const allUsers = state => state.allUsers.map(type => type);
export const paidUnpaidUserDetails = state => state.paidUnpaidUserList;
export const setAllConfigurationData = state => state.setAllConfigurationData;
