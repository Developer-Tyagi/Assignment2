export default function() {
  return {
    mortgages: [],
    selectedMortgage: {},
    mortgagePersonnel: []
  };
}
