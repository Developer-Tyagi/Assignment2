export default function () {
  return {
    photoIdKey: [],
    user: {
      name: ''
    },
    checkConnection: false
  };
}
