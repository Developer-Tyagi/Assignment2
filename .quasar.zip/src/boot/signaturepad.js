import Vue from 'vue';
import SignaturePad from 'vue-signature-pad';

Vue.use(SignaturePad);
